// 📁 server.js
//const app = require('./src/app');
//const PORT = process.env.PORT || 5000;

//app.listen(PORT, () => {
//  console.log(`🚀 Server running on http://localhost:${PORT}`);
//});


const express = require('express');
const app = express();

app.get('/', (req, res) => {
  res.send('Hello from Diabetes Backend!');
});

const port = process.env.PORT || 8080;
app.listen(port, '0.0.0.0', () => {
  console.log(`Server running on http://0.0.0.0:${port}`);
});